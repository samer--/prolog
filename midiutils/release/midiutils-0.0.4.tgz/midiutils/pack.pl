name(midiutils).
version('0.0.4').
author('Samer Abdallah','samer.abdallah.00@gmail.com').
title(midiutils).
download('https://raw.githubusercontent.com/samer--/prolog/master/midiutils/release/midiutils-0.0.4.tgz').
requires(dcgutils).

