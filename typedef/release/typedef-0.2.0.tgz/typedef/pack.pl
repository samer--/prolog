name(typedef).
version('0.2.0').
author('Samer Abdallah','samer.abdallah.00@gmail.com').
title('Support for type definitions').
keywords([types]).
download('https://raw.githubusercontent.com/samer--/prolog/master/typedef/release/typedef-0.2.0.tgz').

