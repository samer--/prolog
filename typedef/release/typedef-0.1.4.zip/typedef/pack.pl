name(typedef).
version('0.1.4').
author('Samer Abdallah','s.abdallah@ucl.ac.uk').
title('Support for type definitions').
keywords([types]).
download('https://raw.githubusercontent.com/samer--/prolog/master/typedef/release/typedef-0.1.4.tgz').

