name(typedef).
version('0.1.3').
author('Samer Abdallah','s.abdallah@ucl.ac.uk').
title('Support for type definitions').
keywords([types]).
download('https://github.com/samer--/prolog/raw/master/typedef/release/typedef-0.1.3.tgz').

